import "dotenv/config";
import express from "express";
import rateLimit from "express-rate-limit";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { buildHealthPayload } from "./appVersion";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  /** IP real atrás de Nginx / proxy (X-Forwarded-For). */
  app.set("trust proxy", 1);
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  app.get("/api/health", (_req, res) => {
    res.json(buildHealthPayload());
  });

  /** API HTTP mínima (além de tRPC em `/api/trpc`). */
  app.get("/api/v1/ping", (_req, res) => {
    res.json({ ...buildHealthPayload(), api: "v1" as const });
  });

  registerStorageProxy(app);

  const rawLimit = process.env.API_RATE_LIMIT_PER_MIN;
  const parsedLimit = rawLimit ? parseInt(rawLimit, 10) : 400;
  const safeLimit = Number.isFinite(parsedLimit)
    ? Math.min(2000, Math.max(60, parsedLimit))
    : 400;

  const trpcLimiter = rateLimit({
    windowMs: 60_000,
    max: safeLimit,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many requests" },
  });

  // tRPC API
  app.use("/api/trpc", trpcLimiter);
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
