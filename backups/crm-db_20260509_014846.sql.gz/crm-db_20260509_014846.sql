-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: crm_telecom
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `__drizzle_migrations`
--

DROP TABLE IF EXISTS `__drizzle_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `__drizzle_migrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `hash` text NOT NULL,
  `created_at` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__drizzle_migrations`
--

LOCK TABLES `__drizzle_migrations` WRITE;
/*!40000 ALTER TABLE `__drizzle_migrations` DISABLE KEYS */;
INSERT INTO `__drizzle_migrations` VALUES (1,'814a08e40d7fc2bcfd458759d18319198ca8ae394f2fa15617a78678e9c9c93b',1778273860270),(2,'6f1b10155059740d0375db1e57db10f23007507a84c5295bb8ff622e3a966e3a',1778273860271),(3,'16408cc5b6b12f0d0326611e63e750b041462afe46970df8245a9f53146de495',1778273860272),(4,'2ae1bf3c77e20039125283b54fb4a43ce2212d04ca0478f106e52c999c52cf8a',1778273860273),(5,'1649ff7aa5f29941e649f0ee2b870c223f750487856b386a6486f7e6149b0c77',1778273860274),(6,'70ba7d8d5fdb7df157d10e08cafada282c6b41d819876773b6b6b05f15a5048f',1778273860275),(7,'ed106766ddf8c695eff72586408a1655e199fd3f492f7cde0ed8d1b5afe968d5',1778273860276),(8,'7af3900f11102b652e3a0a469cbebddc0d2787491cb06622373aa44775f9f8d9',1778273860277),(9,'5d048b6db9cc91147716e54ec072397b8b143cb9f11a5161d421aa71f85d15f9',1778273860278),(10,'bcc2c287d38692a6c7e63f051e19cad4ea74a2f26bc4bf3384d10e7079c5d009',1778283887475),(11,'b4a0561ef49991a1c94bce1abaf3429fed8433dde4294a816c6719741e368381',1778283887475),(12,'352abf80747805cf76c18bacaa8cdc358be3a9c8ecc0abbdbd4ff8267f868636',1778284745108),(13,'16fc3d32e0b6efa41be66729f633ff60876a81ffb415272645732f80cc1d2f54',1778285112156);
/*!40000 ALTER TABLE `__drizzle_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appSettings`
--

DROP TABLE IF EXISTS `appSettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appSettings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `aiEnabled` tinyint(1) NOT NULL DEFAULT '1',
  `openaiApiKeyEnc` text,
  `geminiApiKeyEnc` text,
  `deepseekApiKeyEnc` text,
  `claudeApiKeyEnc` text,
  `preferredAiProvider` enum('openai','gemini','deepseek','claude') NOT NULL DEFAULT 'openai',
  `whatsappEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `whatsappAccessTokenEnc` text,
  `whatsappPhoneNumberId` varchar(64) DEFAULT NULL,
  `whatsappBusinessAccountId` varchar(64) DEFAULT NULL,
  `whatsappVerifyTokenEnc` text,
  `updatedBy` int DEFAULT NULL,
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `forgeApiUrl` varchar(512) DEFAULT NULL,
  `forgeApiKeyEnc` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appSettings`
--

LOCK TABLES `appSettings` WRITE;
/*!40000 ALTER TABLE `appSettings` DISABLE KEYS */;
INSERT INTO `appSettings` VALUES (1,1,NULL,'v1:DUa5lrJJst7IwdOK:Ifb3VrbZnrNUg7IxfxU5Jg==:iYphN4apU1JPtpr6ppVFdHnNGRMRNumTvfWVk1nvrwZj0XboC+W4',NULL,NULL,'gemini',0,NULL,NULL,NULL,NULL,1,'2026-05-09 01:32:46',NULL,NULL);
/*!40000 ALTER TABLE `appSettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auditLogs`
--

DROP TABLE IF EXISTS `auditLogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditLogs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `action` varchar(100) NOT NULL,
  `entity` varchar(100) NOT NULL,
  `entityId` int DEFAULT NULL,
  `details` text,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditLogs`
--

LOCK TABLES `auditLogs` WRITE;
/*!40000 ALTER TABLE `auditLogs` DISABLE KEYS */;
INSERT INTO `auditLogs` VALUES (1,8630,'create','contact',NULL,'Adicionou contacto: +351964231648','2026-05-08 22:40:36'),(2,1,'settings_update','appSettings',NULL,'Atualizou configurações do sistema','2026-05-09 01:32:46');
/*!40000 ALTER TABLE `auditLogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blacklist`
--

DROP TABLE IF EXISTS `blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blacklist` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone` varchar(20) NOT NULL,
  `reason` text,
  `addedBy` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `tenantId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blacklist_phone_tenant` (`phone`,`tenantId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blacklist`
--

LOCK TABLES `blacklist` WRITE;
/*!40000 ALTER TABLE `blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `blacklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendarEvents`
--

DROP TABLE IF EXISTS `calendarEvents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendarEvents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `type` enum('geral','pendente','venda','instalacao') NOT NULL DEFAULT 'geral',
  `startAt` timestamp NOT NULL,
  `endAt` timestamp NULL DEFAULT NULL,
  `allDay` tinyint(1) NOT NULL DEFAULT '1',
  `contactId` int DEFAULT NULL,
  `assignedTo` int DEFAULT NULL,
  `createdBy` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `tenantId` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendarEvents`
--

LOCK TABLES `calendarEvents` WRITE;
/*!40000 ALTER TABLE `calendarEvents` DISABLE KEYS */;
INSERT INTO `calendarEvents` VALUES (1,'Follow-up Carla Mendes — proposta fibra','Ligar antes das 18h; cliente trabalha por turnos.','pendente','2026-05-12 00:11:20','2026-05-12 00:56:20',0,2,143462,143462,'2026-05-09 00:11:20','2026-05-09 00:11:20',143461);
/*!40000 ALTER TABLE `calendarEvents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `callLogs`
--

DROP TABLE IF EXISTS `callLogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `callLogs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contactId` int NOT NULL,
  `vendedorId` int NOT NULL,
  `outcome` enum('atendeu','nao_atende','ocupado','numero_errado','venda','pendente','sem_interesse') NOT NULL,
  `duration` int DEFAULT NULL,
  `notes` text,
  `calledAt` timestamp NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `callLogs`
--

LOCK TABLES `callLogs` WRITE;
/*!40000 ALTER TABLE `callLogs` DISABLE KEYS */;
INSERT INTO `callLogs` VALUES (1,2,143462,'atendeu',NULL,'Primeira chamada — cliente receptiva.','2026-05-09 00:11:20');
/*!40000 ALTER TABLE `callLogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaignFiles`
--

DROP TABLE IF EXISTS `campaignFiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaignFiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `campaignId` int NOT NULL,
  `storageKey` varchar(512) NOT NULL,
  `originalName` varchar(255) NOT NULL,
  `mimeType` varchar(100) NOT NULL,
  `sizeBytes` bigint NOT NULL,
  `uploadedBy` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaignFiles`
--

LOCK TABLES `campaignFiles` WRITE;
/*!40000 ALTER TABLE `campaignFiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaignFiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaigns`
--

DROP TABLE IF EXISTS `campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaigns` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `product` enum('telecom','energia','ambos') NOT NULL DEFAULT 'ambos',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `startDate` timestamp NULL DEFAULT NULL,
  `endDate` timestamp NULL DEFAULT NULL,
  `createdBy` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `tenantId` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaigns`
--

LOCK TABLES `campaigns` WRITE;
/*!40000 ALTER TABLE `campaigns` DISABLE KEYS */;
INSERT INTO `campaigns` VALUES (1,'Fibra + TV Vodafone — Maio 2026 (demo)','Campanha de demonstração com script de objeções e foco em poupança familiar.','telecom',1,'2026-05-01 00:00:00','2026-06-30 00:00:00',143461,'2026-05-09 00:11:20','2026-05-09 00:11:20',143461);
/*!40000 ALTER TABLE `campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `competitorScripts`
--

DROP TABLE IF EXISTS `competitorScripts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `competitorScripts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `competitor` varchar(255) NOT NULL,
  `weakness` text NOT NULL,
  `ourStrength` text NOT NULL,
  `product` enum('telecom','energia','ambos') NOT NULL DEFAULT 'ambos',
  `createdBy` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `tenantId` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `competitorScripts`
--

LOCK TABLES `competitorScripts` WRITE;
/*!40000 ALTER TABLE `competitorScripts` DISABLE KEYS */;
INSERT INTO `competitorScripts` VALUES (1,'NOS','Fidelização 24 meses rígida; penalização na rescisão.','Vodafone permite rever tarifa ao fim de 12 meses com campanhas retention.','telecom',143461,'2026-05-09 00:11:20','2026-05-09 00:11:20',143461);
/*!40000 ALTER TABLE `competitorScripts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contactOrigins`
--

DROP TABLE IF EXISTS `contactOrigins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contactOrigins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `createdBy` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `tenantId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `contact_origins_tenant_name` (`tenantId`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contactOrigins`
--

LOCK TABLES `contactOrigins` WRITE;
/*!40000 ALTER TABLE `contactOrigins` DISABLE KEYS */;
INSERT INTO `contactOrigins` VALUES (1,'Stand Colombo (demo)',143461,'2026-05-09 00:11:20',143461);
/*!40000 ALTER TABLE `contactOrigins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone` varchar(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(320) DEFAULT NULL,
  `address` text,
  `postalCode` varchar(10) DEFAULT NULL,
  `origin` varchar(100) NOT NULL DEFAULT 'Telemarketing',
  `status` enum('novo','em_contacto','pendente','venda','nao_atende','sem_interesse','blacklist') NOT NULL DEFAULT 'novo',
  `assignedTo` int DEFAULT NULL,
  `lastAssignedAt` timestamp NULL DEFAULT NULL,
  `attempts` int NOT NULL DEFAULT '0',
  `lastAttemptAt` timestamp NULL DEFAULT NULL,
  `addedBy` int DEFAULT NULL,
  `hasEnergy` tinyint(1) NOT NULL DEFAULT '0',
  `hasTelecom` tinyint(1) NOT NULL DEFAULT '0',
  `lossReason` varchar(100) DEFAULT NULL,
  `notes` text,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `campaignOffered` varchar(255) DEFAULT NULL,
  `offerValue` varchar(100) DEFAULT NULL,
  `listName` varchar(255) DEFAULT NULL,
  `isLead` tinyint(1) NOT NULL DEFAULT '0',
  `tenantId` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES (1,'+351964231648','Wanderson Borges','wborges.m2018@gmail.com',NULL,NULL,'Telemarketing','novo',NULL,NULL,0,NULL,8630,0,0,NULL,'bvhv','2026-05-08 22:40:36','2026-05-08 22:40:36',NULL,NULL,NULL,0,NULL),(2,'919876543','Carla Mendes','carla.mendes@email.pt',NULL,NULL,'Stand Colombo (demo)','em_contacto',143462,NULL,0,NULL,143461,0,0,NULL,'Interessada em fibra 500 Mbps + TV; comparar com NOS.','2026-05-09 00:11:20','2026-05-09 00:11:20',NULL,NULL,'Lista demo seed',0,143461),(3,'916111222','João Ferreira','joao.f@sapo.pt',NULL,NULL,'Telemarketing','novo',143462,NULL,0,NULL,143461,0,0,NULL,'Lead frio — lista importação demo.','2026-05-09 00:11:20','2026-05-09 00:11:20',NULL,NULL,'Lista demo seed',0,143461),(4,'918555666','Ana Rodrigues','ana.r@gmail.com',NULL,NULL,'Indicação','pendente',143462,NULL,0,NULL,143461,0,0,NULL,'Quer proposta Repsol eletricidade vs tarifa simples.','2026-05-09 00:11:20','2026-05-09 00:11:20',NULL,NULL,'Lista demo seed',0,143461);
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracts`
--

DROP TABLE IF EXISTS `contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contracts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contactId` int NOT NULL,
  `vendedorId` int NOT NULL,
  `type` enum('contrato','portabilidade','rescisao') NOT NULL,
  `product` enum('telecom','energia') NOT NULL,
  `status` enum('gerado','enviado','lido','assinado','cancelado') NOT NULL DEFAULT 'gerado',
  `emailSentAt` timestamp NULL DEFAULT NULL,
  `emailReadAt` timestamp NULL DEFAULT NULL,
  `signedAt` timestamp NULL DEFAULT NULL,
  `installationDate` timestamp NULL DEFAULT NULL,
  `documentUrl` text,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracts`
--

LOCK TABLES `contracts` WRITE;
/*!40000 ALTER TABLE `contracts` DISABLE KEYS */;
INSERT INTO `contracts` VALUES (1,4,143462,'portabilidade','energia','gerado',NULL,NULL,NULL,NULL,NULL,'2026-05-09 00:11:20','2026-05-09 00:11:20');
/*!40000 ALTER TABLE `contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `energyCalculations`
--

DROP TABLE IF EXISTS `energyCalculations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `energyCalculations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contactId` int DEFAULT NULL,
  `vendedorId` int NOT NULL,
  `currentProvider` varchar(100) DEFAULT NULL,
  `currentMonthlyBill` text,
  `currentConsumptionKwh` text,
  `ourOffer` text,
  `estimatedSavings` text,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `energyCalculations`
--

LOCK TABLES `energyCalculations` WRITE;
/*!40000 ALTER TABLE `energyCalculations` DISABLE KEYS */;
/*!40000 ALTER TABLE `energyCalculations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `energyConfig`
--

DROP TABLE IF EXISTS `energyConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `energyConfig` (
  `id` int NOT NULL AUTO_INCREMENT,
  `priceKwhSimples` text NOT NULL DEFAULT (_utf8mb4'0.1500'),
  `priceKwhBiHorariaPonta` text NOT NULL DEFAULT (_utf8mb4'0.2000'),
  `priceKwhBiHorariaVazio` text NOT NULL DEFAULT (_utf8mb4'0.1000'),
  `baseDiscountPercent` text NOT NULL DEFAULT (_utf8mb4'23.00'),
  `vdfClientExtraPercent` text NOT NULL DEFAULT (_utf8mb4'2.00'),
  `vdfGasClientExtraPercent` text NOT NULL DEFAULT (_utf8mb4'3.00'),
  `reembolsoPercent` text NOT NULL DEFAULT (_utf8mb4'3.00'),
  `updatedBy` int DEFAULT NULL,
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `tenantCoordinatorUserId` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `energyConfig`
--

LOCK TABLES `energyConfig` WRITE;
/*!40000 ALTER TABLE `energyConfig` DISABLE KEYS */;
INSERT INTO `energyConfig` VALUES (1,'0.1500','0.2000','0.1000','23.00','2.00','3.00','3.00',NULL,'2026-05-08 20:58:14',NULL),(2,'0.1690','0.1890','0.0990','12','5','3','2',143461,'2026-05-09 00:11:20',143461);
/*!40000 ALTER TABLE `energyConfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gamification`
--

DROP TABLE IF EXISTS `gamification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gamification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `points` int NOT NULL DEFAULT '0',
  `totalCalls` int NOT NULL DEFAULT '0',
  `totalSales` int NOT NULL DEFAULT '0',
  `totalPendentes` int NOT NULL DEFAULT '0',
  `badges` text,
  `month` int NOT NULL,
  `year` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gamification`
--

LOCK TABLES `gamification` WRITE;
/*!40000 ALTER TABLE `gamification` DISABLE KEYS */;
/*!40000 ALTER TABLE `gamification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pendentes`
--

DROP TABLE IF EXISTS `pendentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pendentes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contactId` int NOT NULL,
  `vendedorId` int NOT NULL,
  `returnDate` timestamp NOT NULL,
  `notes` text,
  `offerDesired` text,
  `status` enum('agendado','realizado','expirado','cancelado') NOT NULL DEFAULT 'agendado',
  `notified` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pendentes`
--

LOCK TABLES `pendentes` WRITE;
/*!40000 ALTER TABLE `pendentes` DISABLE KEYS */;
INSERT INTO `pendentes` VALUES (1,2,143462,'2026-05-12 00:11:20','Enviar simulação Vodafone Fibra + cartão adicional.','Pacote família 4 linhas','agendado',0,'2026-05-09 00:11:20','2026-05-09 00:11:20');
/*!40000 ALTER TABLE `pendentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contactId` int NOT NULL,
  `vendedorId` int NOT NULL,
  `product` enum('telecom','energia') NOT NULL,
  `offer` text,
  `value` text,
  `status` enum('aguarda_instalacao','em_aberto','activo','e_switch','cancelado') NOT NULL DEFAULT 'aguarda_instalacao',
  `installationDate` timestamp NULL DEFAULT NULL,
  `closedAt` timestamp NOT NULL DEFAULT (now()),
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `cancelReason` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,2,143462,'telecom','Fibra 500 Mbps + TV mini — promoção 24 meses','€39,99/mês primeiros 6 meses','activo','2026-05-15 10:00:00','2026-05-09 00:11:20','2026-05-09 00:11:20','2026-05-09 00:11:20',NULL);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sosRequests`
--

DROP TABLE IF EXISTS `sosRequests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sosRequests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vendedorId` int NOT NULL,
  `contactId` int DEFAULT NULL,
  `message` text,
  `status` enum('aberto','em_atendimento','resolvido') NOT NULL DEFAULT 'aberto',
  `respondedBy` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `resolvedAt` timestamp NULL DEFAULT NULL,
  `tenantId` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sosRequests`
--

LOCK TABLES `sosRequests` WRITE;
/*!40000 ALTER TABLE `sosRequests` DISABLE KEYS */;
INSERT INTO `sosRequests` VALUES (1,143462,2,'Pedido SOS de demonstração — pode ignorar ou marcar como resolvido.','aberto',NULL,'2026-05-09 00:11:20',NULL,143461);
/*!40000 ALTER TABLE `sosRequests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `leaderId` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `contactEmail` varchar(320) DEFAULT NULL,
  `tenantId` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES (1,'Equipa Demo — Norte',143462,'2026-05-09 00:11:20','equipa.demo@crm-seed.local',143461);
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `openId` varchar(64) NOT NULL,
  `name` text,
  `email` varchar(320) DEFAULT NULL,
  `loginMethod` varchar(64) DEFAULT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `lastSignedIn` timestamp NOT NULL DEFAULT (now()),
  `crmRole` enum('vendedor','cej','ce','coordenador') NOT NULL DEFAULT 'vendedor',
  `teamId` int DEFAULT NULL,
  `isOnline` tinyint(1) NOT NULL DEFAULT '0',
  `lastOnlineAt` timestamp NULL DEFAULT NULL,
  `pauseStartedAt` timestamp NULL DEFAULT NULL,
  `totalPauseMinutes` int NOT NULL DEFAULT '0',
  `totalOnlineMinutes` int NOT NULL DEFAULT '0',
  `password` varchar(255) DEFAULT NULL,
  `isSuperAdmin` tinyint(1) NOT NULL DEFAULT '0',
  `dialerState` enum('idle','ready','in_call','wrap_up') NOT NULL DEFAULT 'idle',
  `dialerContactId` int DEFAULT NULL,
  `dialerSource` enum('queue','pendente') NOT NULL DEFAULT 'queue',
  `dialerUpdatedAt` timestamp NULL DEFAULT NULL,
  `tenantId` int DEFAULT NULL,
  `presenceSessionStartedAt` timestamp NULL DEFAULT NULL,
  `lastSeenIp` varchar(45) DEFAULT NULL,
  `lastSeenUserAgent` varchar(512) DEFAULT NULL,
  `lastSeenGeo` varchar(255) DEFAULT NULL,
  `avatarUrl` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_openId_unique` (`openId`)
) ENGINE=InnoDB AUTO_INCREMENT=143845 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin_bootstrap','Super Admin','admin@crm.local','local','admin','2026-05-08 20:58:14','2026-05-09 01:48:37','2026-05-09 01:48:38','coordenador',NULL,0,'2026-05-09 01:47:54',NULL,0,0,'$2b$10$JxTgBUvkadfoOHiBy2MZluh3VlD1P56uHPbxotSCOnmp6J9yXn4qa',1,'idle',NULL,'queue',NULL,NULL,NULL,'::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36',NULL,NULL),(8630,'local_1778274521266_o3ewq3xncfq','Michell Nascimento','michellerikbrgo@gmail.com','local','admin','2026-05-08 21:08:41','2026-05-08 23:52:37','2026-05-08 23:52:38','coordenador',NULL,1,'2026-05-08 23:09:34',NULL,0,0,'$2b$10$T6dPOHjvheGFKFixoupcluj8hJoFPdoEvS3GaQN5CgbiwX4X28ImG',0,'idle',NULL,'queue',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(31184,'local_1778274697400_h62l0v3f4ym','Carmen','teste@teste.com','local','user','2026-05-08 21:11:37','2026-05-08 21:11:37','2026-05-08 21:11:37','ce',NULL,0,NULL,NULL,0,0,'$2b$10$usSsG0pj/ascCe88cBeIC.BzKSe7lbsKqaXiZkrShArPp9YsGIrgu',0,'idle',NULL,'queue',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(59176,'local_1778280095975_u2m5b0giaz','Wanderson','wborges.m2018@gmail.com','local','user','2026-05-08 22:41:35','2026-05-08 22:41:35','2026-05-08 22:41:35','vendedor',NULL,0,NULL,NULL,0,0,'$2b$10$fGcNqhE5HUlK1f9jJpmQpOUluCFxwaDcggJy80fEB2xUdUUbFBBN.',0,'idle',NULL,'queue',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(143183,'local_1778281626719_g8hu3tumdom','teste','teste1@teste.com','local','user','2026-05-08 23:07:06','2026-05-08 23:07:06','2026-05-08 23:07:06','vendedor',NULL,0,NULL,NULL,0,0,'$2b$10$5lDcquSnX5cZWvB33eXg0OiZ/E4zHcjNlkoJhHZctPQora8yWK05m',0,'idle',NULL,'queue',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(143461,'local_seed_demo_coord_v1','Empresa Demo — Coordenador','demo.coordenador@crm-seed.local','local','admin','2026-05-09 00:11:20','2026-05-09 00:11:20','2026-05-09 00:11:20','coordenador',NULL,0,NULL,NULL,0,0,'$2b$10$u3nw9xqF1GQ/OdeWqsYGQ.vpLHb1SBqUFeMMEb/WIrJg/fhm7tWQ2',0,'idle',NULL,'queue',NULL,143461,NULL,NULL,NULL,NULL,NULL),(143462,'local_seed_demo_vend_v1','Maria Santos (vendedora demo)','demo.vendedor@crm-seed.local','local','user','2026-05-09 00:11:20','2026-05-09 00:11:20','2026-05-09 00:11:20','vendedor',1,0,NULL,NULL,0,0,'$2b$10$u3nw9xqF1GQ/OdeWqsYGQ.vpLHb1SBqUFeMMEb/WIrJg/fhm7tWQ2',0,'idle',NULL,'queue',NULL,143461,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-09  1:48:58
